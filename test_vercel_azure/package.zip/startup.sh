#!/bin/bash
# Set -e to exit on error
set -e

echo "Starting Azure deployment startup script"
echo "Current directory: $(pwd)"
echo "Python version: $(python --version)"

# Create persistent data directory
PERSIST_DIR="/home/site/wwwroot/data"
mkdir -p "$PERSIST_DIR"

# Install dependencies first
echo "Installing dependencies from requirements.txt"
pip install -r requirements.txt

# Make sure flask-cors is specifically installed
echo "Ensuring flask-cors is installed"
pip install flask-cors==3.0.10

# Export database directory 
export DATABASE_DIR="$PERSIST_DIR"
echo "Database directory set to: $DATABASE_DIR"

# Modify app.py to use the persistent path
echo "Patching app.py to use persistent database location"
sed -i "s|DATABASE_DIR = os.environ.get('DATABASE_DIR', os.path.dirname(os.path.abspath(__file__)))|DATABASE_DIR = os.environ.get('DATABASE_DIR', '/home/site/wwwroot/data')|g" app.py

# Check for existing database
if [ ! -f "$PERSIST_DIR/database.db" ]; then
    echo "No database found, initializing at $PERSIST_DIR/database.db"
    # Copy original init_db but modify it to preserve data
    cat > init_db.py << 'EOFDB'
from app import app, get_db
import os
import sqlite3

with app.app_context():
    # Use persistent directory
    db_path = os.path.join(os.environ.get('DATABASE_DIR', '/home/site/wwwroot/data'), 'database.db')
    
    # Only initialize if doesn't exist
    if not os.path.exists(db_path):
        print(f"Database does not exist at {db_path}, initializing...")
        # Initialize the database schema
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.executescript(f.read())
        
        # Add some sample data
        db.execute('INSERT OR IGNORE INTO users (username, email) VALUES (?, ?)', ('user1', 'user1@example.com'))
        db.execute('INSERT OR IGNORE INTO users (username, email) VALUES (?, ?)', ('user2', 'user2@example.com'))
        db.execute('INSERT OR IGNORE INTO users (username, email) VALUES (?, ?)', ('user3', 'user3@example.com'))
        
        # Insert sample comments for different posts
        db.execute('INSERT INTO comments (post_id, content) VALUES (?, ?)', (1, 'Feel free to leave your comments here!',))
        db.execute('INSERT INTO comments (post_id, content) VALUES (?, ?)', (1, 'I found this very helpful for getting started.',))
        db.execute('INSERT INTO comments (post_id, content) VALUES (?, ?)', (2, 'The component explanation was exactly what I needed.',))
        db.execute('INSERT INTO comments (post_id, content) VALUES (?, ?)', (3, 'Looking forward to more posts on routing.',))
        
        db.commit()
        print("Database initialized successfully with sample data.")
    else:
        print(f"Database already exists at {db_path}, skipping initialization.")
        # Just print a quick count of comments for verification
        db = get_db()
        cursor = db.execute('SELECT COUNT(*) FROM comments')
        count = cursor.fetchone()[0]
        print(f"Found {count} existing comments in the database.")
EOFDB
    # Run modified init script
    python init_db.py
else
    echo "Database already exists at $PERSIST_DIR/database.db"
fi

# Show all files in persistent directory
echo "Current files in $PERSIST_DIR:"
ls -la "$PERSIST_DIR"

# Start the app with gunicorn
echo "Starting gunicorn server on port 8000"
gunicorn --bind=0.0.0.0:8000 app:app
