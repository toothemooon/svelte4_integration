#!/usr/bin/env python3
"""
Script to ensure the primary admin user exists in the database.
This is typically run automatically after database initialization via `init_db.py`.
"""
import os
import sys
import sqlite3
from werkzeug.security import generate_password_hash

# Add the parent directory to path to import from app
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Get path to the database
DATABASE_DIR = os.environ.get('DATABASE_DIR', os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
DATABASE = os.path.join(DATABASE_DIR, 'database.db')

# Define the permanent admin credentials
PERMANENT_ADMIN = {
    'username': 'superadmin',
    'password': 'secure_password123!',
    'role': 'admin'
}

def ensure_permanent_admin_exists():
    """
    Ensure the permanent admin user exists in the database.
    If the user doesn't exist, create it.
    If the user exists but isn't admin, update their role.
    """
    admin_info = PERMANENT_ADMIN
    conn = None # Initialize conn to None
    
    try:
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        
        # Check if the specific permanent admin user exists
        cursor = conn.execute('SELECT id, role FROM users WHERE username = ?', (admin_info['username'],))
        existing_user = cursor.fetchone()
        
        if existing_user:
            print(f"Permanent admin user '{admin_info['username']}' already exists (ID: {existing_user['id']}).")
            # Ensure the existing user has the admin role
            if existing_user['role'] != 'admin':
                print(f"Updating user '{admin_info['username']}' to admin role...")
                conn.execute('UPDATE users SET role = ? WHERE username = ?', ('admin', admin_info['username']))
                conn.commit()
                print(f"User '{admin_info['username']}' updated to admin.")
            return
        
        # If user doesn't exist, create them
        print(f"Permanent admin user '{admin_info['username']}' not found. Creating account...")
        
        # Generate a password hash
        password_hash = generate_password_hash(admin_info['password'], method='pbkdf2:sha256')
        
        # Insert the admin user
        cursor = conn.execute(
            'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
            (admin_info['username'], password_hash, admin_info['role'])
        )
        conn.commit()
        
        print(f"Permanent admin user '{admin_info['username']}' created successfully with ID {cursor.lastrowid}.")
        
    except sqlite3.Error as e:
        print(f"Database error ensuring permanent admin exists: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
    finally:
        if conn:
            conn.close()

# Main execution block
if __name__ == "__main__":
    # When run directly, just ensure the permanent admin exists
    ensure_permanent_admin_exists()
    print("\nScript finished. Permanent admin check complete.") 