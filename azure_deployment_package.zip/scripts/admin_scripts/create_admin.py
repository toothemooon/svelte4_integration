#!/usr/bin/env python3
"""
Script to create a permanent admin user in the database
"""
import os
import sys
import sqlite3
from werkzeug.security import generate_password_hash

# Add the parent directory to path to import from app
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# Get the path to the database
DATABASE_DIR = os.environ.get('DATABASE_DIR', os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
DATABASE = os.path.join(DATABASE_DIR, 'database.db')

def create_admin_user(username, password):
    """Create an admin user in the database"""
    # Connect to the database
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    
    try:
        # Check if user already exists
        cursor = conn.execute('SELECT id FROM users WHERE username = ?', (username,))
        existing_user = cursor.fetchone()
        
        if existing_user:
            print(f"User '{username}' already exists with ID {existing_user['id']}")
            
            # Update the existing user to admin role
            conn.execute('UPDATE users SET role = ? WHERE username = ?', ('admin', username))
            conn.commit()
            print(f"Updated user '{username}' to admin role")
            return
        
        # Generate a password hash
        password_hash = generate_password_hash(password, method='pbkdf2:sha256')
        
        # Insert the admin user
        cursor = conn.execute(
            'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)',
            (username, password_hash, 'admin')
        )
        conn.commit()
        
        print(f"Admin user '{username}' created successfully with ID {cursor.lastrowid}")
    
    except sqlite3.Error as e:
        print(f"Error creating admin user: {e}")
    finally:
        conn.close()

def create_permanent_admin():
    """Create a permanent admin user with interactive prompt"""
    print("\n===== Create Permanent Admin User =====")
    username = input("Enter admin username: ")
    password = input("Enter admin password: ")
    
    if not username or not password:
        print("Username and password are required.")
        return
    
    create_admin_user(username, password)

if __name__ == "__main__":
    # If arguments were provided, use them instead of interactive prompt
    if len(sys.argv) == 3:
        create_admin_user(sys.argv[1], sys.argv[2])
    else:
        create_permanent_admin() 