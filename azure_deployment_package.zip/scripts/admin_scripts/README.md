# Admin Scripts

This folder contains admin utility scripts to manage your blog application.

## Creating Admin Users

There are two ways to create admin users:

### 1. Run the `create_admin.py` script

```bash
# Create admin with interactive prompt
python backend/admin_scripts/create_admin.py

# Or specify username and password directly
python backend/admin_scripts/create_admin.py username password
```

This will:
- Create a new admin user if it doesn't exist
- Update an existing user to have admin role

### 2. Run the `ensure_admin.py` script

```bash
python backend/admin_scripts/ensure_admin.py
```

This will:
- Check if any admin user exists in the database
- If no admin users exist, create a default admin (username: admin, password: admin123)
- Optionally add a hook to the database initialization code so that an admin user is automatically created whenever the database is reset

## Making Admin Users Permanent

To ensure that your admin account persists even when the database is reset:

1. Run the `ensure_admin.py` script
2. When prompted, enter 'y' to add the admin user hook to the database initialization code
3. This will modify `app.py` to automatically create an admin user during database initialization if none exists

## Default Credentials

The default admin credentials (if you use `ensure_admin.py`) are:
- Username: `admin`
- Password: `admin123`

**Important Security Note:** You should change the default password in the `DEFAULT_ADMIN` dictionary in `ensure_admin.py` before using it in production. 