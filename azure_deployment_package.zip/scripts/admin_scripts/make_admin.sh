#!/bin/bash
# Simple script to create an admin user quickly

cd "$(dirname "$0")/../../" # Navigate to backend directory from scripts/admin_scripts

echo "Creating an admin user..."

# If arguments provided, use them directly
if [ $# -eq 2 ]; then
    python -c "from scripts.admin_scripts.create_admin import create_admin_user; create_admin_user('$1', '$2')"
    echo "Done! You can now log in with username: $1"
else
    # Otherwise run the full script
    python scripts/admin_scripts/create_admin.py
fi

echo ""
echo "To ensure this admin persists during database resets:"
echo "Run: python scripts/admin_scripts/ensure_admin.py"
echo "And respond 'y' when asked about adding the hook." 